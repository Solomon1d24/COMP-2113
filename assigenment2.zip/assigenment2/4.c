#include <stdio.h>
#include <ctype.h>
#include <string.h>

const int MAX_TEXT_LEN = 50;



int main()
{
  char text[MAX_TEXT_LEN+1];


  scanf("%s", text);
  for (int i =0;text[i] !='\0';i++)
  {int count = 1;
   for (int j=i+1;text[j];j++)
   {
     if(text[j] == text[i])
     {
       count++;
       memmove(&text[j], &text[j+1], strlen(text) - j);
       j--;
     }
   } 

  text[i] = tolower(text[i]);
  printf("%c %d\n", text[i], count);
  }

  return 0;
}
