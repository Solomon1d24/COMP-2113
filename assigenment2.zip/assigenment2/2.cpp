#include <iostream>
#include <limits>
#include <iomanip>
#include <cmath>

using namespace std;

const int X = 0;
const int Y = 1;

const int MAXGEOM = 20;

struct AABB {
  double min[2];  // min[0] = xmin, min[1] = ymin
  double max[2];  // max[0] = xmax, max[1] = ymax
  double midptx, midpty;
  // functions

  // Read a point set from user input and calculates AABB
  void ReadPointSet() {
    int n;
    double x, y;
    cin >> n;
    min[X] = min[Y] = numeric_limits<double>::max();
    max[X] = max[Y] = numeric_limits<double>::lowest();
    for (int i = 0; i < n; ++i) {
      cin >> x >> y;
      if (x < min[X]) min[X] = x;
      if (x > max[X]) max[X] = x;
      if (y < min[Y]) min[Y] = y;
      if (y > max[Y]) max[Y] = y;
      midptx = (max[X] + min[X])/2;
      midpty = (max[Y] + min[Y])/2;
    }
  }

  // Read a rectangle from user input and calculates AABB
  void ReadRectangle() {
    // --- YOUR CODE HERE (Task 1) ---
    double x,y,width,height;
    double x_min_r, x_max_r, y_min_r, y_max_r;
    cin >> x >> y >> width >> height;
    min[X] = min[Y] = numeric_limits<double>::max();
    max[X] = max[Y] = numeric_limits<double>::lowest();
    x_min_r = x - (width/2);
    x_max_r = x + (width/2);
    y_min_r = y - (height/2);
    y_max_r = y + (height/2);

    if (x_min_r < min[X]) min[X] = x_min_r;
    if (x_max_r > max[X]) max[X] = x_max_r;
    if (y_min_r < min[Y]) min[Y] = y_min_r;
    if (y_max_r > max[Y]) max[Y] = y_max_r;

    midptx = (max[X] + min[X])/2;
    midpty = (max[Y] + min[Y])/2;
  }

  // Read a circle from user input and calculates AABB
  void ReadCircle() {
    // --- YOUR CODE HERE (Task 1) ---
    double x,y,radius;
    double x_max_c, y_max_c, x_min_c, y_min_c;
    cin >> x >> y >> radius;
    min[X] = min[Y] = numeric_limits<double>::max();
    max[X] = max[Y] = numeric_limits<double>::lowest();
    x_min_c = x - radius;
    x_max_c = x + radius;
    y_min_c = y - radius;
    y_max_c = y + radius;

    if (x_min_c < min[X]) min[X] = x_min_c;
    if (x_max_c > max[X]) max[X] = x_max_c;
    if (y_min_c < min[Y]) min[Y] = y_min_c;
    if (y_max_c > max[Y]) max[Y] = y_max_c;

    midptx = (max[X] + min[X])/2;
    midpty = (max[Y] + min[Y])/2;
  }

};


// return true if two AABBs overlaps
//        false otherwise
bool IsOverlap(AABB p, AABB q) {
  // --- YOUR CODE HERE (Task 3) ---
  bool overlap = 0;
  if((p.min[X] < q.max[X]) && (p.max[X] > q.min[X]) && (p.max[Y] > q.min[Y]) && (p.min[Y] < q.max[Y]))
  {
    overlap = 1;
  }
  return overlap;
}


int main()
{
  char type;

  AABB boxes[MAXGEOM];

  AABB res; // input AAAB and result AABB
  // initialize bounds of result AABB
  res.min[X] = res.min[Y] = numeric_limits<double>::max();
  res.max[X] = res.max[Y] = numeric_limits<double>::lowest();

  // read geometry type and dispatch to the corresponding
  // AABB read geomety functions to read from user input handle
  // and compute AABB
  // store all AABBs in the array "boxes"
  int numBoxes = 0;

  cin >> type;
  while (type != '#') {
    switch (type) {
      case 'R':
        boxes[numBoxes++].ReadRectangle();
        break;
      case 'C':
        boxes[numBoxes++].ReadCircle();
        break;
      case 'P':
        boxes[numBoxes++].ReadPointSet();
        break;
      default:
        break;
    }
    cin >> type;
  }
  int a=0,b=0;
  // display AABBs for input geometries by going through the array "boxes"
  for (int i = 0; i < numBoxes; ++i) {
    // --- YOUR CODE HERE (Task 2) ---
    if (i%10==0 && i!=0)
    {
        a= a + 1;
    }
    cout << "AABB" << " " << a << i % 10 << ": ";
    cout << boxes[i].min[X] << " " << boxes[i].max[X] << " " << boxes[i].min[Y] << " " << boxes[i].max[Y] << "\n";
    b=+1;
  }

  // for each AABB, if it does not overlap with any other AABBs, display its ID
  // --- YOUR CODE HERE (Task 4) ---
  cout << "Isolated AABBs:\n";
  for (int r =0;r < numBoxes; r++)
    {   bool flag = 0;
        for(int s=0;s < numBoxes;s++)
        {   if(s==r)
            {
                continue;
            }
            if (IsOverlap(boxes[r],boxes[s]) == 1)
            {
                flag = 1;
            }
            
        }
        if (flag == 0)
        {   if (r < 10)
                {cout << "0" << r << endl;}
            if (r == 10)
                {cout << r << endl;}
            if (r > 10)
                {cout << "1" << r%10 << endl;}
            if (r == 20)
                {cout << r << endl;}
        }
    }
  
  return 0;
}
