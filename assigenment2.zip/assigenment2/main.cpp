// d2boh.cpp
#include <iostream>
#include "d2boh.h"
using namespace std;

int main()
{
    int input, output[10] ={};
    char hex[10] = {};
    cout << "Enter a positive integer in the range [1, 100]: ";
    cin>> input;
    int j = decimal_to_binary(input, output);
    int temp = j; 
    cout << "Binary of the given number = ";
    for (j=j-1;j>=0;j--)
    {
        cout << output[j];
    }
    cout << "\n";
    int k = decimal_to_octal(input,output);
    temp = k;
    cout << "Octal of the given number = ";
    for (k=k-1;k>=0;k--)
    {
        cout << output[k];
    }
    cout << "\n";
    int p = decimal_to_hexadecimal(input,hex);
    temp = p;
    cout << "Hexadecimal of the given number = ";
    for(p=p-1;p>=0;p--)
    {
        cout << hex[p];
    }
    cout << "\n";
}