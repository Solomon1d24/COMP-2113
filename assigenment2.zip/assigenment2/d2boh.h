// d2boh.h

#ifndef D2BOH_H
#define D2BOH_H

int decimal_to_binary(int input, int output[10]);
int decimal_to_octal(int input, int output[10]);
int decimal_to_hexadecimal(int input, char output[10]);

#endif
