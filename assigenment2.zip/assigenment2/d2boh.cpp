// d2boh.cpp
#include <iostream>
#include "d2boh.h"
using namespace std;

int decimal_to_binary(int input, int output[10]) {
	// To be implemented
	int i=0;
    for (i=0;input>0;i++)
    {
        output[i] = input%2;
        input = input/2;
    }
    return i;
}

int decimal_to_octal(int input, int output[10]) {
	// To be implemented
    int i = 0;
    for (i = 0;input!=0;i++)
    {
        output[i] = input%8;
        input = input/8;
    }
    return i;
}

int decimal_to_hexadecimal(int input, char output[10]) {
	// To be implemented
    int i = 0;
    while(input!=0)
    {
        int temp = 0;
        temp = input%16;
        if(temp < 10)
        {
            output[i] = temp + 48;
            i++;
        } 
        else
        {
            output[i] = temp + 55;
            i++;
        }
        input = input/16;
    }
    return i;    for (i = 0;input!=0;i++)
    {
        output[i] = input%8;
        input = input/8;
    }
    return i;
}