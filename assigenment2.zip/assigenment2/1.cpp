#include <iostream>

const int MAXDIM = 10;

//----------------------DO NOT CHANGE ANYTHING ABOVE THIS LINE------------------

void read_matrix(int matrix[][10],int &dim)
{   std::cin >> dim;
    for(int i=0;i<dim;i++)
        {
            for(int j=0;j<dim;j++)
                {
                    std::cin >> matrix[i][j];
                }
        }

}

void display_inner_cw_rotated(int matrix[][10],int dim)
{
    int n = dim-1 ;
    for(int i=0;i<(dim/2);i++)
        {
            for(int j=i;j<(dim-i-1);j++)
                {
                    int temp = matrix[i][j];
                    matrix[i][j] = matrix[dim-1-j][i];
                    matrix[dim-1-j][i] = matrix[dim-1-i][dim-1-j];
                    matrix[dim-1-i][dim-1-j] = matrix[j][dim-1-i];
                    matrix[j][dim-1-i] = temp;
                }
        }

    for (int k=1;k<n;k++)
        {
            for(int p=1;p<n;p++)
                {
                    std::cout << matrix[k][p] << " ";
                }
                std::cout << std::endl;
        }

}

//----------------------DO NOT CHANGE ANYTHING BELOW THIS LINE------------------

int main()
{
  int matrix[MAXDIM][MAXDIM]={};
  int dim = 0;

  read_matrix(matrix, dim);
  display_inner_cw_rotated(matrix, dim);

  return 0;
}
