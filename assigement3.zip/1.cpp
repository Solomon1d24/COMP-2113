#include <iostream>
#include <string>
using namespace std;

struct Node
{
	int info;
	Node * next;
};

void insert_node(Node *& head,Node *& tail ,int number)
{
    Node * p = new Node;
    p ->info = number;
    p ->next = NULL;
    if(head == NULL)
    {
        head = p;
        tail = p;
    } 
    else
    {
        tail->next = p;
        tail = p;
    }
}

void print_list(Node * head)
{
    Node * current = head;
    cout << current->info << " -> ";
	current = current->next;
	while (current != head)
	{
		// process the current node, e.g., print the content
		cout << current->info << " -> ";
		current = current->next;
	}
	cout << "tail -> next =" << current->info << "\n";
}

void remove_node(Node * head, int number, int k)
{
    Node *current = head;
    Node *prev = head;
    while(current->next != current)
    {
        int now = 1;
        while(now!=k)
        {
            prev = current;
            current = current->next;
            now++;
        }
        prev->next = current->next;
        delete current;
        current = prev->next;
    }
    cout << current->info << endl;
}

int main()
{
    Node * head = NULL;
    Node * tail = NULL;
    int num , k ;
    cin >> num >> k;
    for (int i = 1; i<=num;i++)
    {
        insert_node(head, tail, i);
    }
    if(tail->next == NULL)
    {
        tail->next = head;
    }
    remove_node(head, num,k);
}